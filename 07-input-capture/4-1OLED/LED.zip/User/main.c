#include "stm32f10x.h"     
#include "DELAY.h"
#include "Function.h"
#include "register.h"
#include "bit.h"
#include "Song.h"
#define a 150  
#define b 300 
#define c 500 
#define d 100

int main(void)
{
	//LED使用PB0~1,PA0~7口，低电平点亮（即阳极接正极，阴极接IO口）
	//IO口采用推挽输出50MHz
	
	
	//Song 铃儿响叮当注释掉运行即可
	/*int pitch[109] = {7,7,3,2,1,7,7,7,7,3,2,1,9,9,9,5,3,2,10,10,7,7,5,2,3,3,7,7,3,2,1,7,7,7,\
		3,2,1,9,9,9,9,5,3,2,7,7,7,7,9,7,5,2,1,3,3,3,3,3,3,3,7,1,2,3,5,5,5,5,5,3,3,3,3,3,2,\
		2,1,2,7,5,5,5,9,9,7,7,3,3,7,7,5,2,1,7,7,5,5,5,9,9,7,3,3,7,7,4,2,1};
	
	int length[109] ={b,b,b,b,b,c,a,a,b,b,b,b,c,b,b,b,b,b,c,b,b,b,b,b,d,b,b,b,b,b,b,c,b,b,\
		b,b,b,c,a,a,b,b,b,b,b,b,b,b,b,b,b,b,c,b,b,c,b,b,c,b,b,b,a,c,b,b,b,a,b,b,b,\
		a,a,b,b,b,b,c,d,b,b,b,a,b,b,b,a,a,b,b,b,b,c,a,a,b,b,b,a,b,b,b,a,a,b,b,b,b,c};
	int i=0;
	while(1)
	{
		while(i++<109)
		{	
				Song(pitch[i],length[i]);
			
		}
	}*/
	
	
	//库函数调用Function函数，1，2，3，分别指全亮全灭，逐次亮，五个五个亮灭
	//Function(1);
	//Function(2);
	//Function(3);
	
	//寄存器调用Register函数，模式如上
	//Register(1);
	//Register(2);
	//Register(3);
	
	//位带操作调用Bit函数，模式如上
	//Bit(1);
	//Bit(2);
	//Bit(3);
}
