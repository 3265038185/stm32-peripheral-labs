#include "stm32f10x.h"     
#include "DELAY.h"
void Function(int x)
{	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin =GPIO_Pin_All;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	GPIO_InitTypeDef GPIOB_InitStructure;
	GPIOB_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIOB_InitStructure.GPIO_Pin =GPIO_Pin_0|GPIO_Pin_1;
	GPIOB_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB,&GPIOB_InitStructure);
	GPIO_SetBits(GPIOA,GPIO_Pin_All);
	GPIO_SetBits(GPIOB,GPIO_Pin_0|GPIO_Pin_1);
	if(x==1)
	{
		
		
		
		while(1)
		{
			//GPIO_Write(GPIOA,~0x)
			GPIO_ResetBits(GPIOA,GPIO_Pin_All);
			GPIO_ResetBits(GPIOB,GPIO_Pin_0|GPIO_Pin_1);
			Delay_ms(500);
			GPIO_SetBits(GPIOA,GPIO_Pin_All);
			GPIO_SetBits(GPIOB,GPIO_Pin_0|GPIO_Pin_1);
			Delay_ms(500);
		}
	}
	else if(x==2)
	{
		while(1)
		{
			
			
			GPIO_ResetBits(GPIOB,GPIO_Pin_1);
			Delay_ms(500);
			GPIO_SetBits(GPIOB,GPIO_Pin_1);

			GPIO_ResetBits(GPIOB,GPIO_Pin_0);
			Delay_ms(500);
			GPIO_SetBits(GPIOB,GPIO_Pin_0);
		
			GPIO_ResetBits(GPIOA,GPIO_Pin_7);
			Delay_ms(500);
			GPIO_SetBits(GPIOA,GPIO_Pin_7);
		
			GPIO_ResetBits(GPIOA,GPIO_Pin_6);
			Delay_ms(500);
			GPIO_SetBits(GPIOA,GPIO_Pin_6);

			GPIO_ResetBits(GPIOA,GPIO_Pin_5);
			Delay_ms(500);
			GPIO_SetBits(GPIOA,GPIO_Pin_5);

			GPIO_ResetBits(GPIOA,GPIO_Pin_4);
			Delay_ms(500);
			GPIO_SetBits(GPIOA,GPIO_Pin_4);

			GPIO_ResetBits(GPIOA,GPIO_Pin_3);
			Delay_ms(500);
			GPIO_SetBits(GPIOA,GPIO_Pin_3);

			GPIO_ResetBits(GPIOA,GPIO_Pin_2);
			Delay_ms(500);
			GPIO_SetBits(GPIOA,GPIO_Pin_2);

			GPIO_ResetBits(GPIOA,GPIO_Pin_1);
			Delay_ms(500);
			GPIO_SetBits(GPIOA,GPIO_Pin_1);

			GPIO_ResetBits(GPIOA,GPIO_Pin_0);
			Delay_ms(500);
			GPIO_SetBits(GPIOA,GPIO_Pin_0);
		}
	}
	else if(x==3)
		{
			while(1)
			{
			GPIO_ResetBits(GPIOB,GPIO_Pin_1);
			GPIO_ResetBits(GPIOB,GPIO_Pin_0);
			GPIO_Write(GPIOA,~0x00E0);

			Delay_ms(500);
		
			GPIO_SetBits(GPIOB,GPIO_Pin_1);
			GPIO_SetBits(GPIOB,GPIO_Pin_0);
			GPIO_Write(GPIOA,~0x0000);
		
			Delay_ms(500);

				
			GPIO_Write(GPIOA,~0x001F);
			Delay_ms(500);
			GPIO_Write(GPIOA,~0x0000);
			Delay_ms(500);

				
			
			}
			
		}
		
	
}
